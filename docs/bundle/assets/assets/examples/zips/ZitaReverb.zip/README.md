## Zita Reverb

This example patch is a Cmajor recreation of the Zita-rev1 reverb effect.

Documentation for the original Zita project is available on the [CCRMA website](https://ccrma.stanford.edu/~jos/Reverb/Zita_Rev1_Reverberator.html).
