
# Filters by Will Pirkle ported to Cmajor

These filters are ported from the C++ projects in Will Pirkle's books
and the application notes on his website

- https://www.willpirkle.com/books/
- https://www.willpirkle.com/app-notes/


uncomment/comment the filters in the FilterTester graph to try the different types. You may also need to comment/uncomment parameters
depending on the filter
