## Additive Piano

This example patch is a model of an electric piano, implemented using additive synthesis.
