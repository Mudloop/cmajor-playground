export default `
    // Here's a very simple graph that plays a sine-wave to get you started..
    processor TSPatch  [[ main ]]
    {
        output stream float out;
        input value float frequency [[ name: "Frequency", min: 5.0f, max: 1000.0f, init: 440.0f ]];

        // This is our processor's entry-point function, which is invoked
        // by the system
        void main()
        {
            loop
            {
                out <- volume * sin (phase);

                let phaseDelta = float (frequency * processor.period * twoPi);
                phase = addModulo2Pi (phase, phaseDelta);
                advance();
            }
        }

        let volume = 0.15f;
        float phase;
    }
`;